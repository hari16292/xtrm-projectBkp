package functionalTestCases;

import org.apache.commons.lang3.RandomStringUtils;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chromium.ChromiumDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v119.network.Network;
import org.openqa.selenium.devtools.v119.network.model.Request;
import org.openqa.selenium.devtools.v119.network.model.RequestId;
import org.openqa.selenium.devtools.v119.network.model.Response;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pageObject.ReportsPage;
import pageObject.SendPage;
import pageObject.SimpleSendPage;
import pageObject.advancedSendPages.*;
import pageObject.commonPages.*;
import resource.BaseClass;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.Duration;
import java.util.*;
import java.util.stream.Stream;

public class TimeCalculationTest extends BaseClass {

    ChromiumDriver driver;
    CommonMenu cm;
    LogoutPage lop;
    SimpleSendPage ssp;
    String accountType;
    long startTime, endTime, totalTime;

    JavascriptExecutor js;
    AdvanceSendStep1Page asp1;
    AdvanceSendStep2Page asp2;
    AdvanceSendStep3Page asp3;
    AdvanceSendStep4Page asp4;
    AdvanceSendStep5Page asp5;
    AdvanceSendStep6Page asp6;

    String downloadedFileName;
    int ranAmt, selectedRecipientsCount;
    ReportsPage rp;

    DevTools devTools;
    WebDriverWait wait;
    LoginPage lp;
    LoginVerificationPage lvp;
    String OTP, compName;

    @BeforeTest
    public void openBrowser() throws Exception {
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(300));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        devTools = driver.getDevTools();
        devTools.createSession();
        devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
        Map<String, Double> timingMap = new HashMap<>();
        devTools.addListener(Network.requestWillBeSent(), request ->
        {
            Request req = request.getRequest();
            if (req.getUrl().contains("/Web/Common/AddFunds/SimpleSendConfirm.aspx") ||
                    req.getUrl().contains("/web/Common/AdvancedSend/AdvanceSendService.asmx/SubmitStep5SendPayment")) {
                RequestId requestId = request.getRequestId();
                double startTime = request.getTimestamp().toJson().doubleValue();
                timingMap.put(requestId.toString(), startTime);
            }
        });

        devTools.addListener(Network.responseReceived(), response ->
        {
            Response res = response.getResponse();
            if (res.getUrl().contains("/Web/Common/AddFunds/SimpleSendConfirm.aspx") ||
                    res.getUrl().contains("/web/Common/AdvancedSend/AdvanceSendService.asmx/SubmitStep5SendPayment")) {
                RequestId reqID = response.getRequestId();
                if (timingMap.get(reqID.toString()) != null) {
                    double endTime = response.getTimestamp().toJson().doubleValue();
                    double responseTime = endTime - timingMap.get(reqID.toString());
                    System.out.println("Response Time for - " + res.getUrl() + " is " + responseTime);
                }
            }
        });
        if (getPropertyValue("environment", "environment").equals("SBox")) {
            driver.get(getPropertyValue("sboxURL", "config"));
        } else {
            driver.get(getPropertyValue("devURL", "config"));
        }
        if (driver.getCurrentUrl().contains("SponsorHome")) {
            waitForElementClickableLocal(cm.getLogoutMenu(), 5);
            cm.getLogoutMenu().click();
            lop = new LogoutPage(driver);
            waitForElementVisibleLocal(lop.getLearnMoreBtn(), 10);
            Assert.assertTrue(driver.getCurrentUrl().contains("Logout"), "Issue in logout");
            if (getPropertyValue("environment", "environment").equals("SBox")) {
                driver.get(getPropertyValue("sboxURL", "config"));
            } else {
                driver.get(getPropertyValue("devURL", "config"));
            }
        }

        lp = new LoginPage(driver);
        lp.getLoginTxt().clear();
        lp.getLoginTxt().sendKeys(getLogin());
        lp.getPasswordTxt().clear();
        lp.getPasswordTxt().sendKeys(getPassword());
        lp.getSignInBtn().click();
        Thread.sleep(5000);
        waitUntilLoaderDisableLocal();
        Assert.assertFalse(driver.getCurrentUrl().contains("Elogin"), "Still in login page");
        if (driver.getCurrentUrl().contains("LoginVerification.aspx")) {
            lvp = new LoginVerificationPage(driver);
            waitForElementVisibleLocal(lvp.getGoBtn(), 2);
            lvp.getVerificationDD().click();
            lvp.getSelectEmail().click();
            lvp.getGoBtn().click();
            OTP = getEmailOTPLocal(getLogin(), "Your login verification code");
            lvp.getOtpTxt().sendKeys(OTP);
            lvp.getVerifyBtn().click();
        }
        cm = new CommonMenu(driver);
        if (getPropertyValue("environment", "environment").equalsIgnoreCase("SBox"))
            compName = "Corpay_Remitter_2_-_Without_Fund";
        else compName = "TestAPICompany";
    }

    @AfterTest
    public void closeBrowser() {
        driver.quit();
    }

    @Test(dataProvider = "simpleSendTestData")
    public void simpleSendTimeTaken(String toAccount, String fromWallet, String amount, String fee, String caseType) throws Exception {
        //Send menu click
        /*LoginTestCase l = new LoginTestCase();
        l.tc02_verificationPage("");*/
        cm.getSendMenu().click();
        waitUntilLoaderDisableLocal();
        Assert.assertTrue(driver.getCurrentUrl().contains("Send"), "Issue in Send menu click. Current URL - " + driver.getCurrentUrl());

        accountType = getPropertyValue("type", "environment");
        if (accountType.equalsIgnoreCase("company")) {
            SendPage sp = new SendPage(driver);
            waitForElementVisibleLocal(sp.getSendBtn(), 5);
            sp.getSimpleSendGoBtn().click();
            waitUntilLoaderDisableLocal();
        }
        Assert.assertTrue(driver.getCurrentUrl().contains("SimpleSend"), "Issue in Simple Send page load. Current URL - " + driver.getCurrentUrl());
        ssp = new SimpleSendPage(driver);
        waitForElementClickableLocal(ssp.getSendToSearchTxt(), 5);
        if (toAccount.equals("NewPersonal")) {
            ssp.getSendToSearchTxt().sendKeys(RandomStringUtils.randomAlphabetic(5) + "autotestuser@mailinator.com");
            waitForElementVisibleLocal(ssp.getRecipientListPopup(), 5);
            waitForElementClickableLocal(ssp.getAddUserBtn(), 5);
            ssp.getAddUserBtn().click();
            waitUntilLoaderDisableLocal();
        } else if (toAccount.equals("NewCompany")) {
            String compName = RandomStringUtils.randomAlphabetic(5) + "AutoTestCompany";
            if (caseType.equals("Positive")) {
                ssp.getSendToSearchTxt().sendKeys(compName);
            } else {
                ssp.getSendToSearchTxt().sendKeys("hari test company");
            }
            waitForElementVisibleLocal(ssp.getRecipientListPopup(), 5);
            waitForElementClickableLocal(ssp.getAddCompanyBtn(), 5);
            ssp.getAddCompanyBtn().click();
            waitUntilLoaderDisableLocal();
            Assert.assertTrue(driver.getCurrentUrl().contains("AddDealer"), "Issue in Add Company button click. Current URL - " + driver.getCurrentUrl());
            waitForElementVisibleLocal(ssp.getCompanyNameAvailMsg(), 5);
            Assert.assertEquals(ssp.getCompanyNameAvailMsg().getText(), "Company name is available");
            ssp.getAdminEmailTxt().sendKeys(compName + "@" + RandomStringUtils.randomAlphabetic(5) + ".com");
            ssp.getAdminFNTxt().sendKeys("Auto");
            ssp.getAdminLNTxt().sendKeys("Test");
            ssp.getAddBtn().click();
            waitUntilLoaderDisableLocal();
            Assert.assertTrue(driver.getCurrentUrl().contains("ManageDealers"), "Issue in Add button click. Current URL - " + driver.getCurrentUrl());
            waitForElementVisibleLocal(ssp.getErrMsg(), 5);
            Assert.assertEquals(ssp.getErrMsg().getText(), "Beneficiary company added and sent to XTRM for compliance approval. Once approved you will be able to pay them. More Info");
        } else {
            ssp.getSendToSearchTxt().sendKeys(getRecipientEmail(toAccount));
            waitForElementVisibleLocal(ssp.getRecipientListPopup(), 5);
            waitForElementClickableLocal(ssp.getSelectRecipientBtn().get(0), 5);
            if (ssp.getSelectRecipientBtn().size() > 1) {
                for (int i = 0; i < ssp.getSelectRecipientBtn().size(); i++) {
                    if (ssp.getSelectRecipientType().get(i).getText().contains("Person") && toAccount.equals("Personal")) {
                        ssp.getSelectRecipientBtn().get(i).click();
                        break;
                    } else if (ssp.getSelectRecipientType().get(i).getText().contains("Company") && toAccount.equals("Company")) {
                        ssp.getSelectRecipientBtn().get(i).click();
                        break;
                    }
                }
            } else ssp.getSelectRecipientBtn().get(0).click();
            waitUntilLoaderDisableLocal();
        }
        waitUntilLoaderDisableLocal();
        Assert.assertTrue(driver.getCurrentUrl().contains("SimpleSendPay"), "Issue in Simple Send Pay page load. Current URL - " + driver.getCurrentUrl());
        waitForElementClickableLocal(ssp.getContinueBtn(), 5);
        Select wallet = new Select(ssp.getFromWalletDD());
        if (accountType.equalsIgnoreCase("company")) {
            wallet.selectByValue(getWalletID(fromWallet));
        } else {
            List<WebElement> walletOption = wallet.getOptions();
            for (WebElement option : walletOption) {
                if (option.getText().substring(0, 3).equals(fromWallet)) {
                    option.click();
                    break;
                }
            }
        }
        if (amount.equals("Random"))
            amount = String.valueOf(getRandomAmount());
        else if (amount.equals("Empty"))
            amount = "";
        ssp.getAmountTxt().sendKeys(amount);
        ssp.getDescriptionTxt().clear();
        ssp.getDescriptionTxt().sendKeys("Selenium Simple Send Auto Test from " + accountType + " to " + toAccount);
        simpleSendProceedButton(1, toAccount);
        waitForElementClickableLocal(ssp.getSendBtn(), 5);
        Assert.assertTrue(ssp.getConfirmAmountValue().getText().contains(String.valueOf(ranAmt)), "Amount mismatched in send confirm page");
        Select feeDD = new Select(ssp.getSelectFeeDD());
        if (fee.equals("Yes")) feeDD.selectByValue("0");
        else feeDD.selectByValue("1");
        Assert.assertEquals(ssp.getDescriptionValue().getText(), "Selenium Simple Send Auto Test from " + accountType + " to " + toAccount);
        simpleSendProceedButton(2, toAccount);

    }

    @DataProvider
    public Object[][] simpleSendTestData() {
        return new Object[][]{
                /*{"toAccount", "fromWallet", "amount", "fee", "caseType"}*/
                {"Company", "USD", "Random", "Yes", "Positive"},
                //{"NewCompany", "USD", "Random", "Yes", "Positive"},
                {"Personal", "USD", "Random", "Yes", "Positive"},
                {"NewPersonal", "USD", "Random", "Yes", "Positive"},
        };
    }

    @Test(dataProvider = "advanceSendTestData")
    public void advanceSendTimeTaken(String paymentType, String fromWallet, String paymentMethod, String condition) throws Exception {
        /*LoginTestCase l = new LoginTestCase();
        l.tc02_verificationPage("");*/
        cm.getSendMenu().click();
        waitUntilLoaderDisableLocal();
        Assert.assertTrue(driver.getCurrentUrl().contains("Send"), "Issue in Send menu click");

        SendPage sp = new SendPage(driver);
        waitForElementVisibleLocal(sp.getSendBtn(), 5);
        sp.getAdvanceGoBtn().click();
        waitUntilLoaderDisableLocal();
        Assert.assertTrue(driver.getCurrentUrl().contains("AdvancedSend"), "Issue in AdvancedSend click");

        advanceSendStep1(paymentType, fromWallet, paymentMethod, condition);
        advanceSendStep2(paymentType, paymentMethod, condition);
        advanceSendStep3(paymentType, paymentMethod, condition);
        advanceSendStep4(condition, paymentType, paymentMethod);
        advanceSendStep5(condition, paymentType, paymentMethod);
    }

    @DataProvider
    public Object[][] advanceSendTestData() {
        return new Object[][]{
                /*{PaymentType, fromWallet, paymentMethod, condition}*/
                {"Personal", "USD", "Wallet", "Next"},
                {"Personal", "USD", "Bank", "Next"},
                {"Personal", "USD", "Check", "Next"},
                {"Company", "USD", "Wallet", "Next"},
                {"Company", "USD", "Bank", "Next"},
                {"Company", "USD", "Check", "Next"},
                {"Employer", "USD", "Wallet", "Next"},
        };
    }

    @Test(dataProvider = "reportTestData")
    public void reportsTimeTaken(String account, String payments, String report, String wallet, String program, String paymentDate, String method, String searchParam, String txn, String fundMethod, String fundSource) throws Exception {
        /*LoginTestCase l = new LoginTestCase();
        l.tc02_verificationPage("");*/
        waitUntilLoaderDisableLocal();
        waitForElementClickableLocal(cm.getReportsMenu(), 5);
        cm.getReportsMenu().click();
        waitUntilLoaderDisableLocal();
        Assert.assertTrue(driver.getCurrentUrl().contains("Common/Report/View"), "Issue in Reports menu click");

        downloadedFileName = null;
        rp = new ReportsPage(driver);
        waitForElementClickableLocal(rp.getDownloadBtn(), 5);
        Select accountDD = new Select(rp.getAccountDD());
        switch (account) {
            case "This Account":
                accountDD.selectByValue("1");
                waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                Select paymentsDD = new Select(rp.getPaymentsDD());
                List<WebElement> paymentsOptions = paymentsDD.getOptions();
                for (WebElement option : paymentsOptions) {
                    if (option.getText().equalsIgnoreCase(payments)) {
                        option.click();
                        waitUntilLoaderDisableLocal();
                        break;
                    }
                }
                if (report.equals("By Payment") || report.equals("By Mass Pay Submission")) {
                    waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                    Select paymentMethodDD = new Select(rp.getPaymentMethodDD());
                    List<WebElement> paymentMethodOptions = paymentMethodDD.getOptions();
                    for (WebElement option : paymentMethodOptions) {
                        if (option.getText().trim().equals(method)) {
                            option.click();
                            waitUntilLoaderDisableLocal();
                            break;
                        } else if (method.isEmpty() || option.getText().equalsIgnoreCase("All")) {
                            //to avoid payment method failure cases
                        } else Assert.fail(method + " not available in Payment Method drop down");
                    }
                }
                if (!report.equals("By Mass Pay Submission")) {
                    waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                    Select walletDD = new Select(rp.getWalletDD());
                    if (wallet.equals("All Wallets"))
                        walletDD.selectByValue("0");
                    else if (wallet.isEmpty()) {
                        //Nothing to do if value is empty
                    } else {
                        walletDD.selectByValue(getWalletID(wallet));
                    }
                }
                if (!program.isEmpty() && !payments.equals("Funded")) {
                    waitUntilLoaderDisableLocal();
                    waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                    Select programDD = new Select(rp.getProgramDD());
                    List<WebElement> programOptions = programDD.getOptions();
                    for (WebElement option : programOptions) {
                        if (option.getText().equals(program)) {
                            option.click();
                            waitUntilLoaderDisableLocal();
                            break;
                        }
                    }
                }
                break;
            case "Beneficiary Company Account":
                startTime = System.currentTimeMillis();
                accountDD.selectByValue("2");
                waitUntilLoaderDisableLocal();
                waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                Select beneficiaryDD = new Select(rp.getBeneficiariesDD());
                List<WebElement> beneficiaryOptions = beneficiaryDD.getOptions();
                for (WebElement option : beneficiaryOptions) {
                    if (option.getText().equalsIgnoreCase(report)) {
                        option.click();
                        waitUntilLoaderDisableLocal();
                        break;
                    }
                }
                break;
            case "Connected Company Account":
                accountDD.selectByValue("3");
                waitUntilLoaderDisableLocal();
                break;
        }
        waitUntilLoaderDisableLocal();
        waitForElementClickableLocal(rp.getDownloadBtn(), 5);
        Select reportDD = new Select(rp.getReportDD());
        reportDD.selectByVisibleText(report);
        switch (report) {
            case "By Payment":
                switch (payments) {
                    case "Sent":
                        downloadedFileName = "By_Payments.csv";
                        break;
                    case "Received":
                        downloadedFileName = "By_Company_Credits.csv";
                        break;
                    case "Funded":
                        downloadedFileName = "By_Funded.csv";
                        break;
                    case "Transferred":
                        downloadedFileName = "By_Transfers.csv";
                        break;
                }
                break;
            case "By Mass Pay Submission":
                if (account.equals("Beneficiary Company Account")) downloadedFileName = ".csv";
                else {
                    downloadedFileName = ".csv";
                    Select paymentMethodDD = new Select(rp.getPaymentMethodDD());
                    paymentMethodDD.selectByVisibleText(method);
                    waitUntilLoaderDisableLocal();
                }
                break;
            case "Claims":
                downloadedFileName = ".csv";
                break;
            case "By Date":
                downloadedFileName = "By_Date.csv";
                break;
            case "By Beneficiary Company":
                downloadedFileName = "By_Partner.csv";
                break;
            case "By Beneficiary Individual":
                downloadedFileName = "By_Person.csv";
                break;
            case "By Beneficiary Individual - Consolidated":
                downloadedFileName = "By_Consolidated_Person.csv";
                break;
            case "Users":
                downloadedFileName = "BeneficiaryCompanyAdminsReport.csv";
                break;
            case "Wallets":
                if (account.equals("Beneficiary Company Account"))
                    downloadedFileName = "BeneficiariesWalletsReport.csv";
                else if (account.equals("Connected Company Account"))
                    downloadedFileName = "ConnectedCompaniesWalletsReport.csv";
                break;
            case "Transactions":
                if (!txn.equals("Pending Fund"))
                    downloadedFileName = "ConnectedAccountsReport_" + compName + ".csv";
                else downloadedFileName = "CAPendingFundReport_" + compName + ".csv";
                waitUntilLoaderDisableLocal();
                waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                Select txnDD = new Select(rp.getTxnDD());
                txnDD.selectByVisibleText(txn);
                waitUntilLoaderDisableLocal();
                if (txn.equals("Pending Fund")) {
                    waitUntilLoaderDisableLocal();
                    waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                    Select fundMethodDD = new Select(rp.getFundMethodDD());
                    fundMethodDD.selectByVisibleText(fundMethod);
                    waitUntilLoaderDisableLocal();
                    waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                    Select fundSourceDD = new Select(rp.getFundSourceDD());
                    fundSourceDD.selectByVisibleText(fundSource);
                    waitUntilLoaderDisableLocal();
                }
                waitUntilLoaderDisableLocal();
                waitForElementClickableLocal(rp.getDownloadBtn(), 5);
                Select currencyDD = new Select(rp.getWalletDD());
                if (!wallet.equalsIgnoreCase("All"))
                    currencyDD.selectByValue(wallet);
                else currencyDD.selectByVisibleText("All");
                break;
        }
        if (!paymentDate.isEmpty()) {
            waitForElementClickableLocal(rp.getPaymentDateRange(), 5);
            rp.getPaymentDateRange().click();
            waitForElementClickableLocal(rp.getPaymentDateCustom(), 5);
            switch (paymentDate) {
                case "This Month":
                    startTime = System.currentTimeMillis();
                    rp.getPaymentDateThisMonth().click();
                    waitUntilLoaderDisableLocal();
                    break;
                case "This Year":
                    startTime = System.currentTimeMillis();
                    rp.getPaymentDateThisYear().click();
                    waitUntilLoaderDisableLocal();
                    break;
                case "Last Year":
                    startTime = System.currentTimeMillis();
                    rp.getPaymentDateLastYear().click();
                    waitUntilLoaderDisableLocal();
                    break;
                case "Custom":
                    rp.getPaymentDateCustom().click();
                    waitForElementClickableLocal(rp.getPaymentDateCustomStartMonthDD(), 5);
                    Select startMonth = new Select(rp.getPaymentDateCustomStartMonthDD());
                    startMonth.selectByValue("0");
                    Select startYear = new Select(rp.getPaymentDateCustomStartYearDD());
                    startYear.selectByValue("2022");
                    waitForElementClickableLocal(rp.getPaymentDateCustomJan1(), 5);
                    rp.getPaymentDateCustomJan1().click();
                    Select endMonth = new Select(rp.getPaymentDateCustomEndMonthDD());
                    endMonth.selectByValue("2");
                    Select endYear = new Select(rp.getPaymentDateCustomStartYearDD());
                    endYear.selectByValue("2022");
                    waitForElementClickableLocal(rp.getPaymentDateCustomMar31(), 5);
                    startTime = System.currentTimeMillis();
                    rp.getPaymentDateCustomMar31().click();
                    waitUntilLoaderDisableLocal();
                    break;
            }
        }
        if (!searchParam.isEmpty()) {
            waitForElementVisibleLocal(rp.getSearchByTxt(), 5);
            rp.getSearchByTxt().sendKeys(searchParam);
            rp.getGoBtn().click();
            waitUntilLoaderDisableLocal();
        }
        if (account.equals("This Account")) {
            try {
                Assert.assertFalse(rp.getShowDetails().isEmpty(), "Transaction details list not available");
                waitForElementVisibleLocal(rp.getShowDetails().get(0), 2);
                endTime = System.currentTimeMillis();
                totalTime = (endTime - startTime) / 1000;
                System.out.println("Reports display time taken for " + account + ", " + payments + " and " + report + " - " + totalTime + " with the transaction count of - " + rp.getFilteredTxnCount().getText());
                Assert.assertTrue(Integer.parseInt(rp.getFilteredTxnCount().getText()) > 0, "Filtered Transaction count is 0");
                startTime = System.currentTimeMillis();
                rp.getDownloadBtn().click();
                waitUntilLoaderDisableLocal();
                verifyDownloadedFile(downloadedFileName, rp.getFilteredTxnCount().getText(), report);
            } catch (Exception e) {
                e.printStackTrace();
                Assert.assertFalse(rp.getNoTxnMsg().isDisplayed(), rp.getNoTxnMsg().getText());
            }
        } else {
            try {
                Assert.assertFalse(rp.getShowDetails().isEmpty(), "Transaction details list not available");
                waitForElementVisibleLocal(rp.getBenCompList().get(0), 2);
                endTime = System.currentTimeMillis();
                totalTime = (endTime - startTime) / 1000;
                System.out.println("Reports display time taken for " + account + " - " + totalTime);
                if (account.equals("Beneficiary Company Account"))
                    Assert.assertFalse(rp.getBenCompList().isEmpty(), "Beneficiary Company List has no records");
                else Assert.assertFalse(rp.getBenCompList().isEmpty(), "Connected Company List has no records");
                rp.getDownloadBtn().click();
                waitUntilLoaderDisableLocal();
                verifyDownloadedFile(downloadedFileName, "", report);
            } catch (Exception e) {
                Assert.assertFalse(rp.getNoTxnMsg().isDisplayed(), rp.getNoTxnMsg().getText());
            }
        }
    }

    @DataProvider
    public Object[][] reportTestData() {
        return new Object[][]{
                /*{"account", "payments", "report", "wallet/currency", "program/beneficiaries/connectedCompanies", "paymentDate", "method", "searchParam", "txn", "fundMethod", "fundSource"}*/
                {"This Account", "Sent", "By Payment", "All Wallets", "", "Last Year", "", "", "", "", ""},
                {"This Account", "Sent", "By Mass Pay Submission", "All Wallets", "", "Last Year", "All", "", "", "", ""},
                {"This Account", "Sent", "By Date", "All Wallets", "", "Last Year", "", "", "", "", ""},
                {"This Account", "Sent", "By Beneficiary Company", "All Wallets", "", "Last Year", "", "", "", "", ""},
                {"This Account", "Sent", "By Beneficiary Individual", "All Wallets", "", "Last Year", "", "", "", "", ""},
                {"This Account", "Sent", "By Beneficiary Individual - Consolidated", "All Wallets", "", "Last Year", "", "", "", "", ""},
                {"This Account", "Received", "By Payment", "All Wallets", "", "Last Year", "", "", "", "", ""},
                {"Connected Company Account", "", "Transactions", "All", "", "Last Year", "", "", "Sent", "", ""},
                {"Connected Company Account", "", "Transactions", "All", "", "Last Year", "", "", "Received", "", ""},
                {"Connected Company Account", "", "By Mass Pay Submission", "", "All Programs", "Last Year", "All", "", "", "", ""},
        };
    }

    @Test(dataProvider = "statementsTestData")
    public void statementsTimeTaken(String walletCurrency, String downloadType, String year, String month, String rangeType, String fileSize) throws Exception {
        /*LoginTestCase l = new LoginTestCase();
        l.tc02_verificationPage("");*/
        waitUntilLoaderDisableLocal();
        waitForElementClickableLocal(cm.getReportsMenu(), 5);
        cm.getReportsMenu().click();
        waitUntilLoaderDisableLocal();
        Assert.assertTrue(driver.getCurrentUrl().contains("Common/Report/View"), "Issue in Reports menu click");
        rp = new ReportsPage(driver);
        waitForElementClickableLocal(rp.getStatementOption(), 5);
        rp.getStatementOption().click();
        waitUntilLoaderDisableLocal();
        waitForElementClickableLocal(rp.getStatementYearDownloadBtn(), 5);
        Assert.assertTrue(driver.getCurrentUrl().contains("Report/Statements"), "Redirected to wrong URL in statement option click - " + driver.getCurrentUrl());
        Select walletDD = new Select(rp.getStatementWalletDD());
        walletDD.selectByValue(getWalletID(walletCurrency));
        waitUntilLoaderDisableLocal();
        waitForElementClickableLocal(rp.getStatementYearDownloadBtn(), 5);
        if (downloadType.equals("Range")) {
            rp.getStatementDateRange().click();
            waitForElementClickableLocal(rp.getRangeLast7DaysOption(), 5);
            switch (rangeType) {
                case "Last 7 Days":
                    rp.getRangeLast7DaysOption().click();
                    break;
                case "Last 30 Days":
                    rp.getRangeLast30DaysOption().click();
                    break;
                case "Last Month":
                    rp.getRangeLastMonthOption().click();
                    break;
                case "This Year":
                    rp.getRangeThisYearOption().click();
                    break;
                case "Last Year":
                    rp.getRangeLastYearOption().click();
                    break;
            }
            startTime = System.currentTimeMillis();
            rp.getRangeDownloadBtn().click();
            waitUntilLoaderDisableLocal();
            waitForElementVisibleLocal(rp.getErrMsg(), 5);
            Assert.assertEquals(rp.getErrMsg().getText(), "Statement downloaded successfully");
            verifyDownloadedFileSize(getDownloadedFileName("Statement_"), fileSize);
        } else {
            Select yearDD = new Select(rp.getStatementYearDD());
            yearDD.selectByValue(year);
            Select monthDD = new Select(rp.getStatementMonthDD());
            monthDD.selectByValue(month);
            rp.getStatementYearDownloadBtn().click();
            waitUntilLoaderDisableLocal();
            waitForElementVisibleLocal(rp.getErrMsg(), 5);
            Assert.assertEquals(rp.getErrMsg().getText(), "Statement downloaded successfully");
            verifyDownloadedFileSize("HTML.pdf", fileSize);
        }

    }

    @DataProvider
    public Object[][] statementsTestData() {
        return new Object[][]{
                /*{"walletCurrency", "downloadType", "year", "monthNo", "rangeType", "fileSize"}*/
                {"USD", "Range", "", "", "This Year", "greaterThan"},
                {"USD", "Range", "", "", "Last Year", "greaterThan"},

        };
    }


    /******************************************************************************************************************/
    public int getRandomAmount() {
        ranAmt = (int) (Math.random() * (15 - 5 + 1) + 5);
        return ranAmt;
    }

    public void simpleSendProceedButton(int stepNumber, String toAccount) {
        if (stepNumber == 1) {
            waitForElementClickableLocal(ssp.getContinueBtn(), 5);
            ssp.getContinueBtn().click();
            waitUntilLoaderDisableLocal();
            Assert.assertTrue(driver.getCurrentUrl().contains("SimpleSendConfirm"), "Issue in Continue button click in step " + stepNumber + ". Current URL - " + driver.getCurrentUrl());
        } else if (stepNumber == 2) {
            waitForElementClickableLocal(ssp.getSendBtn(), 5);
            startTime = System.currentTimeMillis();
            ssp.getSendBtn().click();
            waitUntilLoaderDisableLocal();
            if (accountType.equalsIgnoreCase("user")) {
                Assert.assertTrue(driver.getCurrentUrl().contains("SimpleSendSuccess"), "Issue in Send button click in step " + stepNumber + ". Current URL - " + driver.getCurrentUrl());
                waitForElementClickableLocal(ssp.getViewTxnBtn(), 5);
            } else {
                Assert.assertTrue(driver.getCurrentUrl().contains("ViewCashTransaction"), "Issue in Send button click in step " + stepNumber + ". Current URL - " + driver.getCurrentUrl());
                waitForElementVisibleLocal(ssp.getSuccessMsg(), 5);
            }
            endTime = System.currentTimeMillis();
            totalTime = (endTime - startTime) / 1000;
            System.out.println(accountType + " to " + toAccount + " Simple Send time taken - " + totalTime);
        }
    }

    public void advanceSendStep1(String paymentType, String fromWallet, String paymentMethod, String condition) throws Exception {
        js = driver;
        asp1 = new AdvanceSendStep1Page(driver);
        waitForElementClickableLocal(asp1.getPaymentTypeDD(), 5);
        Select paymentTypeDD = new Select(asp1.getPaymentTypeDD());
        switch (paymentType) {
            case "Personal":
                paymentTypeDD.selectByVisibleText("Personal");
                break;
            case "Company":
                paymentTypeDD.selectByVisibleText("Company");
                break;
            case "Employer":
                paymentTypeDD.selectByVisibleText("Employer");
                break;
        }
        waitForElementClickableLocal(asp1.getPaymentMethodDD(), 5);
        if (paymentType.equals("Employer")) {
            waitForElementVisibleLocal(asp1.getEmployerSearchTxt(), 5);
            asp1.getEmployerSearchTxt().sendKeys(getRecipientEmail("CompanyName"));
            waitForElementVisibleLocal(asp1.getEmployerListPopup(), 5);
            waitForElementClickableLocal(asp1.getEmployerList().get(0), 5);
            boolean isEmployerListAvailable = false;
            for (int i = 0; i < asp1.getEmployerList().size(); i++) {
                waitForElementClickableLocal(asp1.getEmployerListSelectBtn().get(i), 5);
                if (asp1.getEmployerList().get(i).getText().equals(getRecipientEmail("CompanyName"))) {
                    asp1.getEmployerListSelectBtn().get(i).click();
                    isEmployerListAvailable = true;
                    break;
                }
            }
            if (!isEmployerListAvailable) {
                throw new Exception("Searched company " + getRecipientEmail("Company") + " is not listed in employer popup");
            }
        }
        Select paymentMethodDD = new Select(asp1.getPaymentMethodDD());
        switch (paymentMethod) {
            case "Select":
                paymentMethodDD.selectByVisibleText("Select Payment Method");
                break;
            case "Wallet":
                paymentMethodDD.selectByVisibleText("Wallet (Recommended)");
                break;
            case "Bank":
                paymentMethodDD.selectByVisibleText("Direct to Bank");
                break;
            case "Check":
                paymentMethodDD.selectByVisibleText("Direct to Check");
                break;
        }
        Select fromWalletDD = new Select(asp1.getFromWalletDD());
        fromWalletDD.selectByValue(getWalletID(fromWallet));
        asp1.getDescriptionTxt().sendKeys("Selenium Advance Send Auto Test for Company to " + paymentType + " and payment method is " + paymentMethod);
        if (!paymentMethod.equals("Select") && !paymentMethod.equals("Digital Gift Card") && !paymentMethod.equals("Virtual Prepaid Card") && !paymentMethod.equals("Reward Link")) {
            waitForElementVisibleLocal(asp1.getAmountTxt(), 5);
            getRandomAmount();
            String.valueOf(ranAmt);
            js.executeScript("arguments[0].value = '" + ranAmt + "';", asp1.getAmountTxt());
            Thread.sleep(500); //Entered amount got deleted after Next button click without timeout
            asp1.getAmountTxt().clear();
            Thread.sleep(500); //Entered amount got deleted after Next button click without timeout
            asp1.getAmountTxt().sendKeys(String.valueOf(ranAmt));
        }
        advSendProceedButton(condition, 1, paymentType, paymentMethod);
    }

    public void advanceSendStep2(String paymentType, String paymentMethod, String condition) throws Exception {
        waitUntilLoaderDisableLocal();
        asp2 = new AdvanceSendStep2Page(driver);
        waitForElementClickableLocal(asp2.getRecipientSearch(), 20);
        waitUntilLoaderDisableLocal();
        switch (paymentType) {
            case "Personal":
                asp2.getRecipientSearch().sendKeys(getRecipientEmail(paymentType));
                break;
            case "Company":
                asp2.getRecipientSearch().sendKeys(getRecipientEmail("CompanyName"));
                break;
            case "Employer":
                asp2.getRecipientSearch().sendKeys(getRecipientEmail("Employee"));
                break;
        }
        waitForElementClickableLocal(asp2.getAddUser(), 10);
        asp2.getAddUser().click();
        waitUntilLoaderDisableLocal();
        if (paymentMethod.equals("Check")) {
            try {
                Assert.assertTrue(asp2.getCheckMissing().isEmpty(), "Recipient account personal details are missing");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (paymentMethod.equals("Bank")) {
            Select benBank;
            if (asp2.getSelectBank().size() > 1) {
                for (int i = 0; i < asp2.getSelectBank().size(); i++) {
                    benBank = new Select(asp2.getSelectBank().get(i));
                    if (benBank.getOptions().size() > 1) {
                        benBank.selectByIndex(1);
                    } else {
                        //asp2.getDltSelectedRecipientBtn().get(i).click();
                        throw new Exception("Beneficiary Bank not linked");
                    }
                }
            } else {
                benBank = new Select(asp2.getSelectBank().get(0));
                if (benBank.getOptions().size() > 1) {
                    benBank.selectByIndex(1);
                } else {
                    //asp2.getDltSelectedRecipientBtn().get(0).click();
                    throw new Exception("Beneficiary Bank not linked");
                }
            }
        }
        if (!asp2.getSelectedRecipientList().isEmpty()) {
            selectedRecipientsCount = asp2.getSelectedRecipientList().size();
        }
        advSendProceedButton(condition, 2, paymentType, paymentMethod);
    }

    public void advanceSendStep3(String paymentType, String paymentMethod, String condition) {
        asp3 = new AdvanceSendStep3Page(driver);
        waitUntilLoaderDisableLocal();
        waitForElementVisibleLocal(asp3.getAdditionalCommentsTxt().get(0), 5);
        if (!asp3.getAdditionalCommentsTxt().isEmpty()) {
            for (int i = 0; i < asp3.getAdditionalCommentsTxt().size(); i++) {
                Assert.assertEquals(asp3.getAdditionalCommentsTxt().get(i).getAttribute("value"), "Selenium Advance Send Auto Test for Company to " + paymentType + " and payment method is " + paymentMethod);
            }
        }
        for (int i = 0; i < asp3.getAmountTxt().size(); i++) {
            Assert.assertEquals(asp3.getAmountTxt().get(0).getAttribute("value"), ranAmt + ".00");
        }
        advSendProceedButton(condition, 3, paymentType, paymentMethod);
        waitUntilLoaderDisableLocal();
    }

    public void advanceSendStep4(String condition, String paymentType, String paymentMethod) {
        asp4 = new AdvanceSendStep4Page(driver);
        advSendProceedButton(condition, 4, paymentType, paymentMethod);
    }

    public void advanceSendStep5(String condition, String paymentType, String paymentMethod) {
        asp5 = new AdvanceSendStep5Page(driver);
        waitForElementVisibleLocal(asp5.getAmount(), 10);
        advSendProceedButton(condition, 5, paymentType, paymentMethod);
        waitUntilLoaderDisableLocal();
    }

    public void advSendProceedButton(String condition, int stepNumber, String paymentType, String paymentMethod) {
        if (condition.equalsIgnoreCase("Next")) {
            waitForElementClickableLocal(asp1.getNextBtn(), 5);
            asp1.getNextBtn().click();
            waitUntilLoaderDisableLocal();
            waitUntilLoaderDisableLocal();
            if (stepNumber == 5) {
                Assert.assertTrue(asp5.getSendNowTitle().isDisplayed(), "Send Now Confirmation pop up message not showing");
                startTime = System.currentTimeMillis();
                asp5.getSendNowBtn().click();
                waitUntilLoaderDisableLocal();
                asp6 = new AdvanceSendStep6Page(driver);
                waitForElementVisibleLocal(asp6.getPaymentConfirmation(), 30);
                Assert.assertEquals(asp6.getPaymentConfirmation().getText(), "Your payment has been processed.");
                endTime = System.currentTimeMillis();
                totalTime = (endTime - startTime) / 1000;
                System.out.println("Advance Send time taken for " + paymentType + " " + paymentMethod + " payment - " + totalTime);
            }
            if (stepNumber != 0)
                Assert.assertTrue(driver.getCurrentUrl().contains("Step" + (stepNumber + 1) + ".aspx"), "Next button not working in Step number " + stepNumber + ". Current URL - " + driver.getCurrentUrl());
        }
    }

    public void verifyDownloadedFile(@NotNull String fileName, String txnCount, String report) throws Exception {
        String home = System.getProperty("user.home");
        String fileLocation = home + "\\Downloads\\" + fileName;
        File file = new File(fileLocation);
        FluentWait<ChromiumDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(60))
                .pollingEvery(Duration.ofMillis(100));
        wait.until(x -> file.exists());
        endTime = System.currentTimeMillis();
        totalTime = (endTime - startTime) / 1000;
        System.out.println("Reports download time taken - " + totalTime);
        Thread.sleep(1000); //wait for the downloaded file to appear in the downloads folder
        Assert.assertTrue(file.exists(), "File - " + fileName + " not available in downloads folder");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(fileLocation));
        ArrayList<String[]> lines = new ArrayList<>();
        String line;
        String[] distance;
        StringJoiner joiner;
        int rowCount = 0, sum = 0;
        if (report.equals("By Beneficiary Individual - Consolidated")) {
            while ((line = bufferedReader.readLine()) != null) {
                distance = line.replace("\"", "").split("\t");
                lines.add(distance);
            }
            int i = 0;
            for (String[] lineA : lines) {
                if (i == 0) i++;
                else if (i < lines.size() - 1) {
                    joiner = new StringJoiner("");
                    Stream.of(lineA[1].split("\0")).forEach(joiner::add);
                    sum = sum + Integer.parseInt(String.valueOf(joiner));
                    i++;
                }
            }
            System.out.println("Transaction count in downloaded report - " + sum);
            Assert.assertEquals(sum, Integer.parseInt(txnCount), "Count mismatched in downloaded file");
        } else {
            while (bufferedReader.readLine() != null) {
                rowCount++;
            }
            System.out.println("Transaction count in downloaded report - " + (rowCount - 2));
            if (!txnCount.isEmpty())
                Assert.assertEquals(rowCount - 2, Integer.parseInt(txnCount), "Count mismatched in downloaded file");
            else Assert.assertTrue(rowCount >= 2, "No transaction data available in downloaded file");
        }
        bufferedReader.close();
        file.delete();
        Assert.assertFalse(file.exists(), "File - " + fileName + " not deleted and still available in downloads folder");
    }

    public void verifyDownloadedFileSize(String fileName, String fileSize) throws InterruptedException {
        String home = System.getProperty("user.home");
        String fileLocation = home + "\\Downloads\\" + fileName;
        File file = new File(fileLocation);
        FluentWait<ChromiumDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(60))
                .pollingEvery(Duration.ofMillis(100));
        wait.until(x -> file.exists());
        endTime = System.currentTimeMillis();
        totalTime = (endTime - startTime) / 1000;
        System.out.println("Statement download time taken - " + totalTime);
        Thread.sleep(1000); //wait for the downloaded file to appear in the downloads folder
        Assert.assertTrue(file.exists(), "File - " + fileName + " not available in downloads folder");
        if (fileSize.equals("greaterThan"))
            Assert.assertTrue(file.length() > 62000, "File Size is less than minimum, need to check the file content. File size - " + file.length());
        else Assert.assertTrue(file.length() < 62000, "File Size is less than minimum, need to check the file content");
        file.delete();
        Assert.assertFalse(file.exists(), "File - " + fileName + " not deleted and still available in downloads folder");
    }

    public String getDownloadedFileName(String fileName) {
        String home = System.getProperty("user.home");
        String fileLocation = home + "\\Downloads\\";
        File downloads = new File(fileLocation);
        File[] allFile = downloads.listFiles();
        String name = null;
        assert allFile != null;
        for (File file : allFile) {
            if (file.getName().contains(fileName)) {
                name = file.getName();
                break;
            }
        }
        return name;
    }

    public void waitForElementVisibleLocal(WebElement element, int time) {
        wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void waitForElementClickableLocal(WebElement element, int time) {
        wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForElementInvisibleLocal(WebElement element, int time) {
        wait = new WebDriverWait(driver, Duration.ofSeconds(time));
        wait.until(ExpectedConditions.invisibilityOf(element));
    }

    public String getEmailOTPLocal(String email, String subject) {
        driver.switchTo().newWindow(WindowType.TAB);
        driver.get("https://www.mailinator.com/v4/public/inboxes.jsp?to=" + email);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.switchTo().window(windowHandle(driver, "Child"));
        MailinatorPage m = new MailinatorPage(driver);
        List<WebElement> sample = m.getMailList();
        for (WebElement data : sample) {
            if (data.getText().equals(subject)) {
                data.click();
                waitForIFrameAndSwitch(driver, m.getIframe(), 5);
                OTP = m.getMailOTP().getText();
                driver.close();
                break;
            }
        }
        driver.switchTo().window(windowHandle(driver, "Parent"));
        return OTP;
    }

    public void waitUntilLoaderDisableLocal() {
        try {
            waitForElementInvisibleLocal(cm.getLoaderGif(), 20);
            Thread.sleep(2000);//some pages loader image arrived 2 times with few sec time interval
            waitForElementInvisibleLocal(cm.getLoaderGif(), 10);
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

}
