package functionalTestCases;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pageObject.SignUpPage;
import pageObject.commonPages.CommonMenu;
import pageObject.commonPages.LoginPage;
import pageObject.commonPages.LogoutPage;
import resource.BaseClass;

@Listeners(resource.Listeners.class)
public class SignUpTestCase extends BaseClass {

    WebDriver driver = BaseClass.driver;
    String url, randomString;
    CommonMenu cm;
    LogoutPage lop;
    SignUpPage sp;
    LoginPage lp;


    public SignUpTestCase() {
        cm = new CommonMenu(driver);
    }

    @BeforeSuite(groups = {"SignUp", "CompanyRegression", "UserRegression"})
    public void openBrowser() throws Exception {
        if (driver == null) {
            driver = initializeBrowser();
        }
        cm = new CommonMenu(driver);
        sp = new SignUpPage(driver);
    }

    @AfterSuite(groups = {"SignUp", "CompanyRegression", "UserRegression"})
    public void closeBrowser() {
        driver.quit();
    }

    @Test(groups = {"SignUp", "CompanyRegression", "UserRegression"})
    public void tc01_signUpHome() throws Exception {
        if (getPropertyValue("environment", "environment").equals("SBox")) {
            url = getPropertyValue("sboxURL", "config");
        } else {
            url = getPropertyValue("devURL", "config");
        }
        driver.get(url);
        if (driver.getCurrentUrl().contains("SponsorHome") || driver.getCurrentUrl().contains("participanthome")) {
            waitForElementClickable(cm.getLogoutMenu(), 5);
            cm.getLogoutMenu().click();
            lop = new LogoutPage(driver);
            waitForElementClickable(lop.getLoginBtn(), 10);
            Assert.assertTrue(driver.getCurrentUrl().contains("Logout"), "Issue in logout - current URL is " + driver.getCurrentUrl());
            driver.get(url);
        }
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("elogin"), "Redirected to wrong URL - " + driver.getCurrentUrl());
        lp = new LoginPage(driver);
        waitForElementClickable(lp.getSignUpBtn(), 5);
        lp.getSignUpBtn().click();
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("signup"), "Redirected to wrong URL - " + driver.getCurrentUrl());
        randomString = RandomStringUtils.randomAlphabetic(5);
    }

    @Test(dataProvider = "tc02_data", groups = {"SignUp", "CompanyRegression", "UserRegression"})
    public void tc02_personalSignUp(String firstName, String lastName, String email, String password, String mobile, String day, String month, String year, String country, String state, String zipCode, String condition, String errorMsg) throws Exception {
        tc01_signUpHome();
        waitForElementClickable(lp.getSignUpBtn(), 5);
        sp.getPersonalOption().click();
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("simplesignup"), "Redirected to wrong URL - " + driver.getCurrentUrl());
        waitForElementClickable(sp.getContinueBtn(), 5);
        if (country.equalsIgnoreCase("Valid") & !sp.getCountrySpan().getText().equalsIgnoreCase("United States of America")) {
            sp.getCountrySpan().click();
            waitForElementClickable(sp.getCountryDD().get(1), 5);
            sp.getCountryDD().get(225).click();
        }
        sp.getStateSpan().click();
        waitForElementClickable(sp.getStateDD().get(2), 5);
        if (state.equalsIgnoreCase("Valid"))
            sp.getStateDD().get(3).click();
        sp.getFirstNameTxt().sendKeys(firstName);
        if (!lastName.isEmpty())
            sp.getLastNameTxt().sendKeys(lastName + randomString);
        if (email.equalsIgnoreCase("Valid"))
            email = "AutoTestIndividual" + randomString + "@mailinator.com";
        else if (email.equalsIgnoreCase("Invalid"))
            email = "invalidemail";
        else email = "";
        sp.getEmailTxt().sendKeys(email);
        sp.getPasswordTxt().sendKeys(password);
        sp.getMobileTxt().sendKeys(mobile);
        sp.getMonthSpan().click();
        waitForElementClickable(sp.getDobMonthDD().get(4), 5);
        if (month.equalsIgnoreCase("Valid"))
            sp.getDobMonthDD().get(4).click();
        if (day.equalsIgnoreCase("Random"))
            sp.getDobDayTxt().sendKeys(String.valueOf((int) (Math.random() * (27 - 1 + 1) + 1)));
        else sp.getDobDayTxt().sendKeys(day);
        sp.getDobYearTxt().sendKeys(year);
        sp.getZipCodeTxt().sendKeys(zipCode);
        sp.getContinueBtn().click();
        if (condition.equalsIgnoreCase("Positive")) {
            waitForElementClickable(sp.getVerifyEmailBtn(), 10);
            Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("partemailverification"), "Redirected to wrong URL - " + driver.getCurrentUrl());
            sp.getVerifyEmailBtn().click();
            waitUntilLoaderDisable();
            Assert.assertTrue(sp.getWarningMsg().isDisplayed(), "Verification Email Sent message not displayed");
            verifySignUpEmail(email, "Congratulations! You have registered for an XTRM Personal Account");
        } else {
            waitForElementVisible(sp.getWarningMsg(), 5);
            Assert.assertEquals(sp.getWarningMsg().getText(), errorMsg, "Error message invalid");
        }
    }


    @DataProvider
    public Object[][] tc02_data() {
        return new Object[][]{
                /*{"firstName","lastName","email","password","mobile","day","month","year","country","state","zipCode","condition","errorMsg"}*/
                {"Auto", "Test", "Valid", "Auto@123", "9876543210", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Positive", ""},
                {"", "Test", "Valid", "Auto@123", "9876543210", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your first name."},
                {"Auto", "", "Valid", "Auto@123", "9876543210", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your last name."},
                {"Auto", "Test", "empty", "Auto@123", "9876543210", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your email id."},
                {"Auto", "Test", "Valid", "", "9876543210", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your password."},
                {"Auto", "Test", "Valid", "Auto@123", "", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your mobile number."},
                {"Auto", "Test", "Valid", "Auto@123", "abcdef", "Random", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your mobile number."},
                {"Auto", "Test", "Valid", "Auto@123", "9876543210", "0", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your birth date."},
                {"Auto", "Test", "Valid", "Auto@123", "9876543210", "36", "Valid", "1990", "Valid", "Valid", "654231", "Negative", "Please enter your birth date."},
                {"Auto", "Test", "Valid", "Auto@123", "9876543210", "Random", "invalid", "1990", "Valid", "Valid", "654231", "Negative", "Please select your birth month."},
                {"Auto", "Test", "Valid", "Auto@123", "9876543210", "Random", "Valid", "1990", "Valid", "invalid", "654231", "Negative", "Please select your state."},
                {"Auto", "Test", "Valid", "Auto@123", "9876543210", "Random", "Valid", "1990", "Valid", "Valid", "", "Negative", "Please enter your zip code."},
        };
    }

    @Test(dataProvider = "tc03_data", groups = {"SignUp", "CompanyRegression", "UserRegression"})
    public void tc03_companySignUp(String compName, String compWebAddress, String firstName, String lastName, String mobileNo, String compEmail, String password, String condition, String errorMsg) throws Exception {
        tc01_signUpHome();
        waitForElementClickable(lp.getSignUpBtn(), 5);
        sp.getCompanyOption().click();
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("sponsimplesignup"), "Redirected to wrong URL - " + driver.getCurrentUrl());
        waitForElementClickable(sp.getContinueBtn(), 5);
        if (compName.equalsIgnoreCase("Valid"))
            compName = "AutoTestCompany" + randomString;
        else if (compName.equalsIgnoreCase("Invalid"))
            compName = "AutoTestCompany";
        else compName = "";
        sp.getCompanyName().sendKeys(compName);
        sp.getCompWebAddress().sendKeys(compWebAddress);
        sp.getFirstNameTxt().sendKeys(firstName);
        sp.getLastNameTxt().sendKeys(lastName);
        sp.getMobileTxt().sendKeys(mobileNo);
        if (compEmail.equalsIgnoreCase("Valid"))
            compEmail = "AutoTestCompany" + randomString + "@mailinator.com";
        else if (compEmail.equalsIgnoreCase("Invalid"))
            compEmail = "invalidemail";
        else compEmail = "";
        sp.getEmailTxt().sendKeys(compEmail);
        sp.getPasswordTxt().sendKeys(password);
        sp.getContinueBtn().click();
        waitUntilLoaderDisable();
        if (condition.equalsIgnoreCase("Positive")) {
            waitForElementClickable(sp.getVerifyEmailBtn(), 10);
            Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("memsponemailverification"), "Redirected to wrong URL - " + driver.getCurrentUrl());
            sp.getVerifyEmailBtn().click();
            waitUntilLoaderDisable();
            Assert.assertTrue(sp.getWarningMsg().isDisplayed(), "Verification Email Sent message not displayed");
            verifySignUpEmail(compEmail, "You have successfully completed the first step registering your company to XTRM");
        } else {
            waitForElementVisible(sp.getWarningMsg(), 5);
            Assert.assertEquals(sp.getWarningMsg().getText(), errorMsg, "Error message invalid");
        }
    }

    @DataProvider
    public Object[][] tc03_data() {
        return new Object[][]{
                /*{"compName", "compWebAddress", "firstName", "lastName", "mobileNo", "compEmail", "password", "condition", "errorMsg"}*/
                {"Valid", "www.autotest.in", "Auto", "Test", "9876543210", "Valid", "Auto@123", "Positive", ""},
                {"Empty", "www.autotest.in", "Auto", "Test", "9876543210", "Valid", "Auto@123", "Negative", "Please enter your company name."},
                {"Valid", "www.autotest.in", "", "Test", "9876543210", "Valid", "Auto@123", "Negative", "Please enter your first name."},
                {"Valid", "www.autotest.in", "Auto", "", "9876543210", "Valid", "Auto@123", "Negative", "Please enter your last name."},
                {"Valid", "www.autotest.in", "Auto", "Test", "", "Valid", "Auto@123", "Negative", "Please enter your phone number."},
                {"Valid", "www.autotest.in", "Auto", "Test", "abcdef", "Valid", "Auto@123", "Negative", "Please enter your phone number."},
                {"Valid", "www.autotest.in", "Auto", "Test", "9876543210", "Empty", "Auto@123", "Negative", "Please enter your email id."},
                {"Valid", "www.autotest.in", "Auto", "Test", "9876543210", "Valid", "", "Negative", "Please enter your password."},
        };
    }

}
