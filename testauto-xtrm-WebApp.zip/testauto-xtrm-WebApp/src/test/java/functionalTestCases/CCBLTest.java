package functionalTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pageObject.LinkBank_CardsPage;
import pageObject.LinkedCardsPage;
import pageObject.commonPages.CommonMenu;
import resource.BaseClass;

@Listeners(resource.Listeners.class)
public class CCBLTest extends BaseClass {

    WebDriver driver = BaseClass.driver;
    CommonMenu cm;
    LinkBank_CardsPage lp;
    LinkedCardsPage lcp;
    LoginTestCase lt;
    int bankCount;
    BanksTestCase bt;

    @BeforeSuite(groups = {"Banks", "CompanyRegression", "UserRegression", "LinkRapidCard"})
    public void openBrowser() throws Exception {
        if (driver == null) {
            driver = initializeBrowser();
        }
        cm = new CommonMenu(driver);
        lp = new LinkBank_CardsPage(driver);
        lcp = new LinkedCardsPage(driver);
    }

    @AfterSuite(groups = {"Banks", "CompanyRegression", "UserRegression", "LinkRapidCard"})
    public void closeBrowser() {
        driver.quit();
    }


    @Test(groups = {"Banks", "CompanyRegression", "UserRegression", "LinkRapidCard"})
    public void tc01_homePage() throws Exception {
        bt = new BanksTestCase();
        bankCount = bt.deleteBank();
        lt = new LoginTestCase();
        lt.tc02_verificationPage("");
        if (getPropertyValue("type", "environment").equalsIgnoreCase("Company")) {
            cm.getBanksMenu().click();
            waitUntilLoaderDisable();
            Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("payment"), "Banks menu click redirected to wrong URL - " + driver.getCurrentUrl());
        } else {
            cm.getSettingsIcon().click();
            waitUntilLoaderDisable();
            waitForElementClickable(lp.getLinkedBanksTab(), 5);
            lp.getLinkedBanksTab().click();
            waitUntilLoaderDisable();
        }
        waitForElementClickable(lp.getLinkBankAccountBtn(), 5);
        lp.getLinkBankAccountBtn().click();
        waitUntilLoaderDisable();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        waitUntilLoaderDisable();
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("choosepaymethod"), "LinkBankButton click redirected to wrong URL - " + driver.getCurrentUrl());
    }

    @Test
    public void tc02_linkBankTransfer() throws Exception {
        tc01_homePage();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        lp.getTransferGoBtn().click();
        waitUntilLoaderDisable();
        waitForElementClickable(lp.getTransferLinkContinueBtn(), 5);
        Select bankCountryDD = new Select(lp.getTransferBankCountryDD());
        boolean ccblEnabled;
        for (int i = 0; i < bankCountryDD.getOptions().size(); i++) {
            ccblEnabled = true;
            bankCountryDD.selectByIndex(i);
            waitUntilLoaderDisable();
            waitForElementClickable(lp.getTransferLinkContinueBtn(), 5);
            if (lp.getTransferCurrencyDD().getAttribute("class").contains("hide"))
                ccblEnabled = false;
            Select currency = new Select(lp.getTransferCurrencyDD());
            getScreenshot(bankCountryDD.getFirstSelectedOption().getText());
            if ((ccblEnabled))
                System.out.println(bankCountryDD.getFirstSelectedOption().getText() + " - has " + currency.getOptions().size() + " currencies");
            else System.out.println(bankCountryDD.getFirstSelectedOption().getText() + " - has single currency");
        }
    }
}
