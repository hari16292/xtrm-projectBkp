package functionalTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.*;
import pageObject.IdentityPage;
import pageObject.LinkBank_CardsPage;
import pageObject.ProfilePage;
import pageObject.commonPages.CommonMenu;
import resource.BaseClass;

@Listeners(resource.Listeners.class)
public class ProgressBarTestCase extends BaseClass {
    WebDriver driver = BaseClass.driver;
    CommonMenu cm;
    ProfilePage pp;
    LinkBank_CardsPage lp;
    IdentityPage ip;

    @BeforeSuite(groups = {"ProgressBar", "CompanyRegression"})
    public void openBrowser() throws Exception {
        if (driver == null) {
            driver = initializeBrowser();
        }
        cm = new CommonMenu(driver);
        pp = new ProfilePage(driver);
        lp = new LinkBank_CardsPage(driver);
        ip = new IdentityPage(driver);
    }

    @AfterSuite(groups = {"ProgressBar", "CompanyRegression"})
    public void closeBrowser() {
        driver.quit();
    }

    @Test(groups = {"ProgressBar", "CompanyRegression"})
    public void tc01_homePage() throws Exception {
        LoginTestCase l = new LoginTestCase();
        l.tc02_verificationPage("ProgressBar Company");
        cm.getIdentityMenu().click();
        waitUntilLoaderDisable();
        Assert.assertTrue(driver.getCurrentUrl().contains("IdentitySummary"), "Issue in Identity menu click");
    }

    @Test(dataProvider = "tc02_data", groups = {"ProgressBar", "CompanyRegression"})
    public void tc02_companyProgressBar(String profileStatus) throws Exception {
        tc01_homePage();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        deleteOptionalField();
        deleteBank();
        cm.getIdentityMenu().click();
        waitUntilLoaderDisable();
        deleteIdentityDocument();
        checkUpdatedStatus("30", "red", "Draft");
        pp.getOrganizationHeader().click();
        waitUntilLoaderDisable();
        pp.getOrgWebAddrTxt().sendKeys("xtrm.com");
        switch (profileStatus) {
            case "Basic":
                updateProfile();
                checkUpdatedStatus("35", "blue", "Basic");
                break;
            case "Standard":
                verifyStandard();
                deleteBank();
                break;
            case "Advanced":
                verifyStandard();
                pp.getIdentityDocumentsHeader().click();
                waitUntilLoaderDisable();
                waitForElementClickable(pp.getIdentityDocUploadBtn(), 5);
                pp.getIdentityDocUploadBtn().click();
                waitUntilLoaderDisable();
                waitForElementClickable(cm.getLogoutMenu(), 5);
                Select uploadDocDD = new Select(pp.getDocIdentityDocumentDD());
                uploadDocDD.selectByValue("1");
                pp.getDocChooseFileBtn().sendKeys(System.getProperty("user.dir") + "/src/main/java/resource/dummyUpload.png");
                waitUntilLoaderDisable();
                waitForElementClickable(cm.getLogoutMenu(), 5);
                //Assert.assertEquals(pp.getDocUploadMsg().getText(), "Document uploaded successfully", "Upload success message missing");
                cm.getIdentityMenu().click();
                checkUpdatedStatus("85", "orange", "Standard");
                expireIdentityDocument(1);
                checkUpdatedStatus("75", "orange", "Standard");
                unExpireIdentityDocument(1);
                checkUpdatedStatus("85", "orange", "Standard");
                pp.getIdentityDocumentsHeader().click();
                waitUntilLoaderDisable();
                pp.getDocUploadBtn().click();
                waitUntilLoaderDisable();
                uploadDocDD.selectByValue("3");
                pp.getDocChooseFileBtn().sendKeys(System.getProperty("user.dir") + "/src/main/java/resource/dummyUpload.png");
                waitUntilLoaderDisable();
                waitForElementClickable(cm.getLogoutMenu(), 5);
                //Assert.assertEquals(pp.getDocUploadMsg().getText(), "Document uploaded successfully", "Upload success message missing");
                cm.getIdentityMenu().click();
                checkUpdatedStatus("90", "orange", "Standard");
                expireIdentityDocument(3);
                checkUpdatedStatus("85", "orange", "Standard");
                unExpireIdentityDocument(3);
                checkUpdatedStatus("90", "orange", "Standard");
                pp.getIdentityDocumentsHeader().click();
                waitUntilLoaderDisable();
                pp.getDocUploadBtn().click();
                waitUntilLoaderDisable();
                uploadDocDD.selectByValue("4");
                pp.getDocChooseFileBtn().sendKeys(System.getProperty("user.dir") + "/src/main/java/resource/dummyUpload.png");
                waitUntilLoaderDisable();
                waitForElementClickable(cm.getLogoutMenu(), 5);
                //Assert.assertEquals(pp.getDocUploadMsg().getText(), "Document uploaded successfully", "Upload success message missing");
                cm.getIdentityMenu().click();
                checkUpdatedStatus("100", "green", "Standard");
                expireIdentityDocument(4);
                checkUpdatedStatus("90", "orange", "Standard");
                unExpireIdentityDocument(4);
                checkUpdatedStatus("100", "green", "Standard");
                /*pp.getDocumentsHeader().click();
                waitUntilLoaderDisable();
                for (int i = 0; i < pp.getDocDeleteOption().size(); i++) {
                    pp.getDocDeleteOption().get(i).click();
                    waitUntilLoaderDisable();
                    Assert.assertEquals(pp.getDocUploadMsg().getText(), "Document removed successfully", "Delete success message missing");
                }
                deleteBank();*/
        }
    }

    @DataProvider
    public Object[][] tc02_data() {
        return new Object[][]{
                /*{"profileStatus"}*/
                /*{"Basic"}, {"Standard"},*/ {"Advanced"}
        };
    }


    /******************************************************************************************************************/

    public void deleteOptionalField() {
        pp.getOrganizationHeader().click();
        waitUntilLoaderDisable();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        pp.getOrgPhoneNumberTxt().clear();
        pp.getOrgWebAddrTxt().clear();
        pp.getOrgTaxID().sendKeys(" ");
        pp.getOrgAddr1Txt().clear();
        pp.getOrgCityTxt().clear();
        Select stateDD = new Select(pp.getOrgStateDD());
        stateDD.selectByValue("Select State/County/Region");
        pp.getOrgZipCodeTxt().clear();
        pp.getOrgUpdateBtn().click();
        waitUntilLoaderDisable();
        waitForElementVisible(pp.getErrorMsg(), 5);
        Assert.assertEquals(pp.getErrorMsg().getText(), "Organization details successfully updated", "Profile update getting error");
    }

    public String checkProfileCompletion() {
        waitForElementClickable(cm.getLogoutMenu(), 5);
        return pp.getProgressBarStatus().getText().replace("%", "").trim();
    }

    public String checkStatusBarColour() {
        waitForElementClickable(cm.getLogoutMenu(), 5);
        return pp.getProgressBarColour().getAttribute("class").replace("bar ", "").trim();
    }

    public void updateProfile() {
        waitForElementClickable(pp.getOrgUpdateBtn(), 5);
        pp.getOrgUpdateBtn().click();
        waitUntilLoaderDisable();
        waitForElementVisible(cm.getLogoutMenu(), 5);
    }

    public void checkUpdatedStatus(String percentage, String colour, String identityLevel) {
        Assert.assertEquals(checkProfileCompletion(), percentage, "Profile Status percentage value changed");
        Assert.assertEquals(checkStatusBarColour(), colour, "Progress bar colour not in " + colour);
        //need to fix this error
        //Assert.assertEquals(ip.getIdentityLevelTxt().getText(), identityLevel, "Organization Identity Level is not " + identityLevel);
    }

    public void linkBank() {
        lp.getTransferBankNameTxt().sendKeys("Bank of America Corporation");
        lp.getTransferAccountNumberTxt().sendKeys("44332211");
        lp.getTransferLinkContinueBtn().click();
        waitUntilLoaderDisable();
        lp.getTransferReEnterAccountNumberTxt().sendKeys("44332211");
        lp.getTransferRoutingTxt().sendKeys("011000138");
        lp.getTransferLinkContinueBtn().click();
        waitUntilLoaderDisable();
    }

    public void deleteBank() {
        cm.getBanksMenu().click();
        waitUntilLoaderDisable();
        Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("payment"), "Banks menu click redirected to wrong URL - " + driver.getCurrentUrl());
        if (!lp.getBankDetailsDD().isEmpty()) {
            for (int i = 0; i <= lp.getBankDetailsDD().size(); i++) {
                lp.getBankDetailsDD().get(0).click();
                waitForElementClickable(lp.getBankDeleteOption().get(0), 5);
                lp.getBankDeleteOption().get(0).click();
                waitUntilLoaderDisable();
                waitForElementVisible(lp.getBankMsg(), 5);
                Assert.assertEquals(lp.getBankMsg().getText(), "Bank account deleted successfully", "Displayed bank successful delete message is not valid");
                waitForElementClickable(lp.getLinkBankAccountBtn(), 5);
            }
        }
    }

    public void verifyStandard() {
        pp.getOrgPhoneNumberTxt().sendKeys("9876543210");
        pp.getOrgTaxID().sendKeys("123465");
        pp.getOrgAddr1Txt().sendKeys("Test Address1");
        pp.getOrgCityTxt().sendKeys("Test City");
        Select stateDD = new Select(pp.getOrgStateDD());
        stateDD.selectByValue("9");
        pp.getOrgZipCodeTxt().sendKeys("456465");
        updateProfile();
        checkUpdatedStatus("65", "blue", "Basic");
        pp.getIdentityHeader().click();
        waitUntilLoaderDisable();
        waitForElementClickable(pp.getOrgLinkBankLinkOption(), 5);
        pp.getOrgLinkBankLinkOption().click();
        waitUntilLoaderDisable();
        waitForElementClickable(lp.getLinkBankAccountBtn(), 5);
        lp.getLinkBankAccountBtn().click();
        waitUntilLoaderDisable();
        waitForElementClickable(lp.getTransferGoBtn(), 5);
        lp.getTransferGoBtn().click();
        waitUntilLoaderDisable();
        linkBank();
        cm.getIdentityMenu().click();
        waitUntilLoaderDisable();
        checkUpdatedStatus("75", "orange", "Standard");
    }

    public void deleteIdentityDocument() {
        pp.getIdentityDocumentsHeader().click();
        waitUntilLoaderDisable();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        int docCount = ip.getDeleteIdentityDocOption().size();
        for (int i = 0; i < docCount; i++) {
            ip.getDeleteIdentityDocOption().get(0).click();
            waitUntilLoaderDisable();
        }
        waitForElementClickable(cm.getLogoutMenu(), 5);
        Select statusDD = new Select(ip.getStatusDD());
        statusDD.selectByValue("0");
        waitUntilLoaderDisable();
        docCount = ip.getDeleteIdentityDocOption().size();
        for (int i = 0; i < docCount; i++) {
            ip.getDeleteIdentityDocOption().get(0).click();
            waitUntilLoaderDisable();

        }
    }

    public void expireIdentityDocument(int docType) {
        pp.getIdentityDocumentsHeader().click();
        waitUntilLoaderDisable();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        int docCount;
        switch (docType) {
            case 1:
                docCount = ip.getExpireIdentityDocOption().size();
                for (int i = 0; i < docCount; i++) {
                    if(ip.getDocTypeTxt().get(i).getText().equals("Driving Licence")) {
                        ip.getExpireIdentityDocOption().get(i).click();
                        waitUntilLoaderDisable();
                        break;
                    }
                }
                break;
            case 3:
                docCount = ip.getExpireIdentityDocOption().size();
                for (int i = 0; i < docCount; i++) {
                    if(ip.getDocTypeTxt().get(i).getText().equals("Company Tax Document")) {
                        ip.getExpireIdentityDocOption().get(i).click();
                        waitUntilLoaderDisable();
                        break;
                    }
                }
                break;
            case 4:
                docCount = ip.getExpireIdentityDocOption().size();
                for (int i = 0; i < docCount; i++) {
                    if(ip.getDocTypeTxt().get(i).getText().equals("Utility Bill")) {
                        ip.getExpireIdentityDocOption().get(i).click();
                        waitUntilLoaderDisable();
                        break;
                    }
                }
                break;
        }
        Assert.assertEquals(pp.getDocUploadMsg().getText(), "Document expired successfully", "Expired success message missing");
        /*for (int i = 0; i < docCount; i++) {
            ip.getExpireIdentityDocOption().get(0).click();
            waitUntilLoaderDisable();
        }*/
    }

    public void unExpireIdentityDocument(int docType) {
        pp.getIdentityDocumentsHeader().click();
        waitUntilLoaderDisable();
        waitForElementClickable(cm.getLogoutMenu(), 5);
        Select statusDD = new Select(ip.getStatusDD());
        statusDD.selectByValue("0");
        waitUntilLoaderDisable();
        int docCount;
        switch (docType) {
            case 1:
                docCount = ip.getDocTypeTxt().size();
                for (int i = 0; i < docCount; i++) {
                    if(ip.getDocTypeTxt().get(i).getText().equals("Driving Licence")) {
                        ip.getExpireIdentityDocOption().get(i).click();
                        waitUntilLoaderDisable();
                        break;
                    }
                }
                break;
            case 3:
                docCount = ip.getDocTypeTxt().size();
                for (int i = 0; i < docCount; i++) {
                    if(ip.getDocTypeTxt().get(i).getText().equals("Company Tax Document")) {
                        ip.getExpireIdentityDocOption().get(i).click();
                        waitUntilLoaderDisable();
                        break;
                    }
                }
                break;
            case 4:
                docCount = ip.getDocTypeTxt().size();
                for (int i = 0; i < docCount; i++) {
                    if(ip.getDocTypeTxt().get(i).getText().equals("Utility Bill")) {
                        ip.getExpireIdentityDocOption().get(i).click();
                        waitUntilLoaderDisable();
                        break;
                    }
                }
                break;
        }
        Assert.assertEquals(pp.getDocUploadMsg().getText(), "Document un-expired successfully", "Un-expired success message missing");
    }
}
