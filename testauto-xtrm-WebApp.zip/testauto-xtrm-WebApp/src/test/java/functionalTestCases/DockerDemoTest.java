package functionalTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import java.net.URL;

public class DockerDemoTest {
    ChromeOptions co = new ChromeOptions();
    @Test
    public void chrome1() throws Exception {
        WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4545/wd/hub"), co);
        driver.get("https://www.google.com/");
        Thread.sleep(20000);
        driver.quit();
    }

    @Test
    public void chrome2() throws Exception {
        WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4545/wd/hub"), co);
        driver.get("https://www.google.com/");
        Thread.sleep(20000);
        driver.quit();
    }

    @Test
    public void chrome3() throws Exception {
        WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4545/wd/hub"), co);
        driver.get("https://www.google.com/");
        Thread.sleep(20000);
        driver.quit();
    }

    @Test
    public void chrome4() throws Exception {
        WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4545/wd/hub"), co);
        driver.get("https://www.google.com/");
        Thread.sleep(20000);
        driver.quit();
    }

    @Test
    public void chrome5() throws Exception {
        WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4545/wd/hub"), co);
        driver.get("https://www.google.com/");
        Thread.sleep(20000);
        driver.quit();
    }
    
}
