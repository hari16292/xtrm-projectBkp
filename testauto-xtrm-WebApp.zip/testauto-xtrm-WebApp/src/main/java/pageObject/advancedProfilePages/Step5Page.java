package pageObject.advancedProfilePages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Step5Page {
    WebDriver driver;

    public Step5Page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "(//input[@value='Done'])[2]")
    private WebElement doneBtn;

    @FindBy(xpath = "(//input[@value='Done'])[2]/../../../h2[@class='fs-title']")
    private WebElement successMsg;

    @FindBy(xpath = "(//h2[@class='fs-title'][contains(text(),'Advanced Services Application Submitted Successful')])[3]")
    private WebElement successMsg1;

    @FindBy(xpath = "(//input[@value='Done'])[3]")
    private WebElement doneBtn1;

    @FindBy(id = "ownerselJobTitle")
    private WebElement jobTitleDD;

    @FindBy(id = "ownertxtPercentageOwned")
    private WebElement percentOwnedTxt;

    @FindBy(id = "ownertxtFirstName")
    private WebElement ownerFNTxt;

    @FindBy(id = "ownertxtMiddleName")
    private WebElement ownerMNTxt;

    @FindBy(id = "ownertxtLastName")
    private WebElement ownerLNTxt;

    @FindBy(id = "ownerselDOBMonth")
    private WebElement dobMonthDD;

    @FindBy(id = "ownertxtDOBDay")
    private WebElement dobDayTxt;

    @FindBy(id = "ownertxtDOBYear")
    private WebElement dobYearTxt;

    @FindBy(id = "ownertxtEmail")
    private WebElement emailTxt;

    @FindBy(id = "ownerselCitizenship")
    private WebElement nationalityDD;

    @FindBy(id = "ownertxtAddress")
    private WebElement addr1Txt;

    @FindBy(id = "ownertxtCity")
    private WebElement cityTxt;

    @FindBy(id = "ownerselCountry")
    private WebElement countryDD;

    @FindBy(id = "ownerselState")
    private WebElement stateDD;

    @FindBy(id = "ownertxtPostalCode")
    private WebElement zipcodeTxt;

    @FindBy(xpath = "(//input[@value='Finish and Submit'])[5]")
    private WebElement submitBtn;

    @FindBy(xpath = "(//input[@name='previous'])[7]")
    private WebElement previousBtn;






    public WebElement getDoneBtn() {
        return doneBtn;
    }

    public WebElement getSuccessMsg() {
        return successMsg;
    }

    public WebElement getSuccessMsg1() {
        return successMsg1;
    }

    public WebElement getDoneBtn1() {
        return doneBtn1;
    }

    public WebElement getJobTitleDD() {
        return jobTitleDD;
    }

    public WebElement getPercentOwnedTxt() {
        return percentOwnedTxt;
    }

    public WebElement getOwnerFNTxt() {
        return ownerFNTxt;
    }

    public WebElement getOwnerMNTxt() {
        return ownerMNTxt;
    }

    public WebElement getOwnerLNTxt() {
        return ownerLNTxt;
    }

    public WebElement getDobMonthDD() {
        return dobMonthDD;
    }

    public WebElement getDobDayTxt() {
        return dobDayTxt;
    }

    public WebElement getDobYearTxt() {
        return dobYearTxt;
    }

    public WebElement getEmailTxt() {
        return emailTxt;
    }

    public WebElement getNationalityDD() {
        return nationalityDD;
    }

    public WebElement getAddr1Txt() {
        return addr1Txt;
    }

    public WebElement getCityTxt() {
        return cityTxt;
    }

    public WebElement getCountryDD() {
        return countryDD;
    }

    public WebElement getStateDD() {
        return stateDD;
    }

    public WebElement getZipcodeTxt() {
        return zipcodeTxt;
    }

    public WebElement getSubmitBtn() {
        return submitBtn;
    }

    public WebElement getPreviousBtn() {
        return previousBtn;
    }
}
