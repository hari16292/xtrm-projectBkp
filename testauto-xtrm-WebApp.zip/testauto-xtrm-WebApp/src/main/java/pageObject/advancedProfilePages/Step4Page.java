package pageObject.advancedProfilePages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Step4Page {
    WebDriver driver;

    public Step4Page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "(//input[@name='previous'])[5]")
    private WebElement previousBtn;

    @FindBy(xpath = "(//input[@name='next'])[7]")
    private WebElement saveContinueBtn;

    @FindBy(id = "rdnNo")
    private WebElement entityNoRadioBtn;

    @FindBy(id = "rdnYes")
    private WebElement entityYesRadioBtn;

    @FindBy(xpath = "//input[@class='hs-button primary large action-button submit btnstep5submit']")
    private WebElement finishAndSubmitBtn;

    @FindBy(id = "txtTradeTickerSymbol")
    private WebElement tickerSymbolTxt;

    public WebElement getPreviousBtn() {
        return previousBtn;
    }

    public WebElement getSaveContinueBtn() {
        return saveContinueBtn;
    }

    public WebElement getEntityNoRadioBtn() {
        return entityNoRadioBtn;
    }

    public WebElement getEntityYesRadioBtn() {
        return entityYesRadioBtn;
    }

    public WebElement getFinishAndSubmitBtn() {
        return finishAndSubmitBtn;
    }

    public WebElement getTickerSymbolTxt() {
        return tickerSymbolTxt;
    }
}
