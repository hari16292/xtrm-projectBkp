package pageObject.advancedProfilePages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Step1Page {
    WebDriver driver;

    public Step1Page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(linkText = "Company (Advanced)")
    private WebElement advancedProfileTabOption;

    @FindBy(xpath = "//span[normalize-space()='Identity Level:']/../a")
    private WebElement advancedMoreInfoLink;

    @FindBy(xpath = "//div[@id='ctl00_ctl00_TopMenu_MiniTab_divHelpText']/a")
    private WebElement advancedMoreInfo1Link;

    @FindBy(xpath = "//span[@id='ctl00_ctl00_TopMenu_MiniTab_lblAdvancedServices']//a")
    private WebElement advancedMoreInfo2Link;

    @FindBy(xpath = "//h2[contains(text(),'Please complete and submit your advanced profile b')]/a")
    private WebElement advancedMoreInfo3Link;

    @FindBy(xpath = "//a[normalize-space()='Advanced Services']")
    private WebElement advancedServicesLink;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_ddlCountry")
    private WebElement countryDD;

    @FindBy(xpath = "//span[normalize-space()='Payments Type:']")
    private WebElement paymentTypeVisibleText;
    @FindBy(id = "ddlRemitterType")
    private WebElement paymentTypeDD;

    @FindBy(xpath = "(//input[@name='next'])[2]")
    private WebElement nextBtn;

    @FindBy(xpath = "//div[@class='divDomestic']")
    private WebElement USPagesCount;

    @FindBy(xpath = "//div[@class='divInternational']")
    private WebElement InternationalPagesCount;

    @FindBy(xpath = "//ul[@id='USprogressbar']/li[1]")
    private WebElement pageNumOne;

    @FindBy(xpath = "//ul[@id='USprogressbar']/li[2]")
    private WebElement pageNumTwo;

    @FindBy(xpath = "//ul[@id='USprogressbar']/li[3]")
    private WebElement pageNumThree;

    @FindBy(xpath = "//ul[@id='progressbar']/li[1]")
    private WebElement pageNumOneInternational;

    @FindBy(xpath = "//ul[@id='progressbar']/li[2]")
    private WebElement pageNumTwoInternational;

    @FindBy(xpath = "//ul[@id='progressbar']/li[3]")
    private WebElement pageNumThreeInternational;

    @FindBy(xpath = "//ul[@id='progressbar']/li[4]")
    private WebElement pageNumFourInternational;

    @FindBy(xpath = "//ul[@id='progressbar']/li[5]")
    private WebElement pageNumFiveInternational;

    @FindBy(xpath = "//span[normalize-space()='New support ticket']")
    private WebElement newSupportTicketLink;

    public WebElement getAdvancedProfileTabOption() {
        return advancedProfileTabOption;
    }

    public WebElement getAdvancedMoreInfoLink() {
        return advancedMoreInfoLink;
    }

    public WebElement getAdvancedMoreInfo1Link() {
        return advancedMoreInfo1Link;
    }

    public WebElement getAdvancedMoreInfo2Link() {
        return advancedMoreInfo2Link;
    }

    public WebElement getAdvancedMoreInfo3Link() {
        return advancedMoreInfo3Link;
    }

    public WebElement getAdvancedServicesLink() {
        return advancedServicesLink;
    }

    public WebElement getCountryDD() {
        return countryDD;
    }

    public WebElement getPaymentTypeVisibleText() {
        return paymentTypeVisibleText;
    }

    public WebElement getPaymentTypeDD() {
        return paymentTypeDD;
    }

    public WebElement getNextBtn() {
        return nextBtn;
    }

    public WebElement getUSPagesCount() {
        return USPagesCount;
    }

    public WebElement getInternationalPagesCount() {
        return InternationalPagesCount;
    }

    public WebElement getPageNumOne() {
        return pageNumOne;
    }

    public WebElement getPageNumTwo() {
        return pageNumTwo;
    }

    public WebElement getPageNumThree() {
        return pageNumThree;
    }

    public WebElement getPageNumOneInternational() {
        return pageNumOneInternational;
    }

    public WebElement getPageNumTwoInternational() {
        return pageNumTwoInternational;
    }

    public WebElement getPageNumThreeInternational() {
        return pageNumThreeInternational;
    }

    public WebElement getPageNumFourInternational() {
        return pageNumFourInternational;
    }

    public WebElement getPageNumFiveInternational() {
        return pageNumFiveInternational;
    }

    public WebElement getNewSupportTicketLink() {
        return newSupportTicketLink;
    }
}
