package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class BeneficiariesPage {
    WebDriver driver;

    public BeneficiariesPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtSearch")
    private WebElement searchTxt;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_ddlFilter")
    private WebElement filterDD;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_ddlSort")
    private WebElement sortBy;

    @FindBy(linkText = "More Info")
    private WebElement moreInfoLink;

    @FindBy(xpath = "//p[@class='small'][4]")
    private List<WebElement> personalBeneficiaryListMail;

    @FindBy(linkText = "Add New Personal Beneficiary")
    private WebElement addNewBeneficiaryBtn;

    @FindBy(xpath = "//*[contains(@class,'dropdown dropdown-bubble')]/button[contains(@id,'dLabel')]")
    private List<WebElement> menuDD;

    @FindBy(xpath = "//*[contains(@class,'NaviDropDown')]/a[contains(@class,'mdrnButton primary')]")
    private List<WebElement> sendBtn;

    @FindBy(linkText = "Add")
    private WebElement addBtn;

    @FindBy(id = "spnMsg")
    private WebElement message;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'Remove Beneficiary')]")
    private WebElement removeOption;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'Profile')]")
    private WebElement viewProfileOption;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'View Wallets')]")
    private WebElement viewWalletsOption;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'View Linked Banks') or contains(text(),'View Linked banks')]")
    private WebElement viewLinkedBanksOption;

    @FindBy(linkText = "Company Beneficiaries")
    private WebElement companyBeneficiaryButton;

    @FindBy(linkText = "Personal Beneficiaries")
    private WebElement personalBeneficiaryButton;

    @FindBy(className = "CompanyNameLink")
    private List<WebElement> companyBeneficiaryName;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'View Users')]")
    private WebElement viewUsersOption;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'View Employees')]")
    private WebElement viewEmployeesOption;

    @FindBy(xpath = "//ul[@class='dropdown-menu show']//a[contains(text(),'Edit Organization Details')]")
    private WebElement editCompanyDetailsOption;

    @FindBy(linkText = "Activity")
    private List<WebElement> activityBtn;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_lnkbtnExport")
    private WebElement downloadBtn;

    @FindBy(xpath = "//ul[@id='No-Results']/li")
    private List<WebElement> noResultMsgTxt;

    public WebElement getSearchTxt() {
        return searchTxt;
    }

    public WebElement getFilterDD() {
        return filterDD;
    }

    public WebElement getSortBy() {
        return sortBy;
    }

    public WebElement getMoreInfoLink() {
        return moreInfoLink;
    }

    public List<WebElement> getPersonalBeneficiaryListMail() {
        return personalBeneficiaryListMail;
    }

    public WebElement getAddNewBeneficiaryBtn() {
        return addNewBeneficiaryBtn;
    }

    public List<WebElement> getMenuDD() {
        return menuDD;
    }

    public List<WebElement> getSendBtn() {
        return sendBtn;
    }

    public WebElement getAddBtn() {
        return addBtn;
    }

    public WebElement getMessage() {
        return message;
    }

    public WebElement getRemoveOption() {
        return removeOption;
    }

    public WebElement getViewProfileOption() {
        return viewProfileOption;
    }

    public WebElement getViewWalletsOption() {
        return viewWalletsOption;
    }

    public WebElement getViewLinkedBanksOption() {
        return viewLinkedBanksOption;
    }

    public WebElement getCompanyBeneficiaryButton() {
        return companyBeneficiaryButton;
    }

    public WebElement getPersonalBeneficiaryButton() {
        return personalBeneficiaryButton;
    }

    public List<WebElement> getCompanyBeneficiaryName() {
        return companyBeneficiaryName;
    }

    public WebElement getViewUsersOption() {
        return viewUsersOption;
    }

    public WebElement getViewEmployeesOption() {
        return viewEmployeesOption;
    }

    public WebElement getEditCompanyDetailsOption() {
        return editCompanyDetailsOption;
    }

    public List<WebElement> getActivityBtn() {
        return activityBtn;
    }

    public WebElement getDownloadBtn() {
        return downloadBtn;
    }

    public List<WebElement> getNoResultMsgTxt() {
        return noResultMsgTxt;
    }
}
