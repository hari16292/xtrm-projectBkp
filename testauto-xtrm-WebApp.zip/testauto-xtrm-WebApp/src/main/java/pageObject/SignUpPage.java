package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class SignUpPage {
    WebDriver driver;

    public SignUpPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "personal")
    private WebElement personalOption;

    @FindBy(id = "company")
    private WebElement companyOption;

    @FindBy(id = "ctl00_MainContent_txtFirstName")
    private WebElement firstNameTxt;

    @FindBy(id = "ctl00_MainContent_txtLastName")
    private WebElement lastNameTxt;

    @FindBy(id = "ctl00_MainContent_txtEMail")
    private WebElement emailTxt;

    @FindBy(id = "ctl00_MainContent_txtPassword")
    private WebElement passwordTxt;

    @FindBy(xpath = "//input[@id='ctl00_MainContent_txtMobileNumber' or @id='ctl00_MainContent_txtPhoneNumber']")
    private WebElement mobileTxt;

    @FindBy(xpath = "//div[contains(@class,'nice-select form-control ddlMonth')]//ul[@class='list']/li")
    private List<WebElement> dobMonthDD;

    @FindBy(xpath = "//div[contains(@class,'nice-select form-control ddlMonth')]")
    private WebElement monthSpan;

    @FindBy(id = "ctl00_MainContent_txtDay")
    private WebElement dobDayTxt;

    @FindBy(id = "ctl00_MainContent_txtYear")
    private WebElement dobYearTxt;

    @FindBy(xpath = "//div[@class='controls divCountry']/div[contains(@class,'nice-select form-control')]/ul/li")
    private List<WebElement> countryDD;

    @FindBy(xpath = "//div[@class='controls divCountry']/div[contains(@class,'nice-select form-control')]")
    private WebElement countrySpan;

    @FindBy(xpath = "//div[contains(@class,'nice-select form-control ddlState')]/ul/li")
    private List<WebElement> stateDD;

    @FindBy(xpath = "//div[contains(@class,'nice-select form-control ddlState')]")
    private WebElement stateSpan;

    @FindBy(id = "ctl00_MainContent_txtZipcode")
    private WebElement zipCodeTxt;

    @FindBy(id = "ctl00_MainContent_btnContinue1")
    private WebElement continueBtn;

    @FindBy(id = "ctl00_MainContent_btnRegister")
    private WebElement verifyEmailBtn;

    @FindBy(xpath = "//div[@id='notifications']/p")
    private WebElement warningMsg;

    @FindBy(id = "ctl00_MainContent_txtOrgName")
    private WebElement companyName;

    @FindBy(id = "ctl00_MainContent_txtWebAddr")
    public WebElement compWebAddress;


    public WebElement getPersonalOption() {
        return personalOption;
    }

    public WebElement getCompanyOption() {
        return companyOption;
    }

    public WebElement getFirstNameTxt() {
        return firstNameTxt;
    }

    public WebElement getLastNameTxt() {
        return lastNameTxt;
    }

    public WebElement getEmailTxt() {
        return emailTxt;
    }

    public WebElement getPasswordTxt() {
        return passwordTxt;
    }

    public WebElement getMobileTxt() {
        return mobileTxt;
    }

    public List<WebElement> getDobMonthDD() {
        return dobMonthDD;
    }

    public WebElement getMonthSpan() {
        return monthSpan;
    }

    public WebElement getDobDayTxt() {
        return dobDayTxt;
    }

    public WebElement getDobYearTxt() {
        return dobYearTxt;
    }

    public List<WebElement> getCountryDD() {
        return countryDD;
    }

    public List<WebElement> getStateDD() {
        return stateDD;
    }

    public WebElement getCountrySpan() {
        return countrySpan;
    }

    public WebElement getStateSpan() {
        return stateSpan;
    }

    public WebElement getZipCodeTxt() {
        return zipCodeTxt;
    }

    public WebElement getContinueBtn() {
        return continueBtn;
    }

    public WebElement getVerifyEmailBtn() {
        return verifyEmailBtn;
    }

    public WebElement getWarningMsg() {
        return warningMsg;
    }

    public WebElement getCompanyName() {
        return companyName;
    }

    public WebElement getCompWebAddress() {
        return compWebAddress;
    }
}
