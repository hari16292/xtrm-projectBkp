package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class ProfilePage {

    WebDriver driver;

    public ProfilePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(linkText = "Organization Details")
    private WebElement organizationHeader;

    @FindBy(linkText = "Identity")
    private WebElement identityHeader;

    @FindBy(linkText = "Identity Documents")
    private WebElement identityDocumentsHeader;

    @FindBy(linkText = "You (Master Admin)")
    private WebElement masterAdminHeader;

    @FindBy(linkText = "Documents")
    private WebElement documentsHeader;

    @FindBy(linkText = "Advanced Services Application")
    private WebElement ASAHeader;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtPhone1")
    private WebElement orgPhoneNumberTxt;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtWebAddr")
    private WebElement orgWebAddrTxt;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtAddress1")
    private WebElement orgAddr1Txt;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtCity")
    private WebElement orgCityTxt;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_ddlState")
    private WebElement orgStateDD;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtZip")
    private WebElement orgZipCodeTxt;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_btnAddLinkDocument")
    private WebElement identityDocUploadBtn;

    @FindBy(xpath = "//a[@href='/Web/Common/WithdrawFunds/Payment.aspx'][normalize-space()='Update']")
    private WebElement orgLinkBankLinkOption;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_btnUpdate")
    private WebElement orgUpdateBtn;

    @FindBy(id = "ddlIdentityDocumentType")
    private WebElement docIdentityDocumentDD;

    @FindBy(id = "fuIdentityDocument")
    private WebElement docChooseFileBtn;

    @FindBy(xpath = "//div[@class='percent']")
    private WebElement progressBarStatus;

    @FindBy(xpath = "//div[@class='progress']/div")
    private WebElement progressBarColour;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_lblMsg")
    private WebElement errorMsg;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_txtSSN")
    private WebElement orgTaxID;

    @FindBy(id = "lblMessage")
    private WebElement docUploadMsg;

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_btnAddLinkDocument")
    private WebElement docUploadBtn;

    @FindBy(xpath = "(//a[@class='clsDelete clsStyle'][normalize-space()='Delete'])")
    private List<WebElement> docDeleteOption;

    @FindBy(xpath = "//span[@id='spnAdminLevel']/../a")
    private WebElement roleTxt;

    public WebElement getOrganizationHeader() {
        return organizationHeader;
    }

    public WebElement getIdentityHeader() {
        return identityHeader;
    }

    public WebElement getIdentityDocumentsHeader() {
        return identityDocumentsHeader;
    }

    public WebElement getMasterAdminHeader() {
        return masterAdminHeader;
    }

    public WebElement getDocumentsHeader() {
        return documentsHeader;
    }

    public WebElement getASAHeader() {
        return ASAHeader;
    }

    public WebElement getOrgPhoneNumberTxt() {
        return orgPhoneNumberTxt;
    }

    public WebElement getOrgWebAddrTxt() {
        return orgWebAddrTxt;
    }

    public WebElement getOrgAddr1Txt() {
        return orgAddr1Txt;
    }

    public WebElement getOrgCityTxt() {
        return orgCityTxt;
    }

    public WebElement getOrgStateDD() {
        return orgStateDD;
    }

    public WebElement getOrgZipCodeTxt() {
        return orgZipCodeTxt;
    }

    public WebElement getIdentityDocUploadBtn() {
        return identityDocUploadBtn;
    }

    public WebElement getOrgLinkBankLinkOption() {
        return orgLinkBankLinkOption;
    }

    public WebElement getOrgUpdateBtn() {
        return orgUpdateBtn;
    }

    public WebElement getDocIdentityDocumentDD() {
        return docIdentityDocumentDD;
    }

    public WebElement getDocChooseFileBtn() {
        return docChooseFileBtn;
    }

    public WebElement getProgressBarStatus() {
        return progressBarStatus;
    }

    public WebElement getProgressBarColour() {
        return progressBarColour;
    }

    public WebElement getErrorMsg() {
        return errorMsg;
    }

    public WebElement getOrgTaxID() {
        return orgTaxID;
    }

    public WebElement getDocUploadMsg() {
        return docUploadMsg;
    }

    public WebElement getDocUploadBtn() {
        return docUploadBtn;
    }

    public List<WebElement> getDocDeleteOption() {
        return docDeleteOption;
    }

    public WebElement getRoleTxt() {
        return roleTxt;
    }
}
