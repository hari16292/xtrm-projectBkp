package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class IdentityPage {

    WebDriver driver;

    public IdentityPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_spnAccountIdentity")
    private WebElement identityLevelTxt;

    @FindBy(xpath = "//table[@id='ctl00_ctl00_TopMenu_MiniTab_tblResult']/tbody/tr/td/span/a[@class='clsDelete clsStyle']")
    private List<WebElement> deleteIdentityDocOption;

    @FindBy(xpath = "//table[@id='ctl00_ctl00_TopMenu_MiniTab_tblResult']/tbody/tr/td/span/a[@class='clsDocStatus clsStyle']")
    private List<WebElement> expireIdentityDocOption;

    @FindBy(id = "ddlStatus")
    private WebElement statusDD;

    @FindBy(xpath = "//table[@id='ctl00_ctl00_TopMenu_MiniTab_tblResult']/tbody/tr/td[1]/span")
    private List<WebElement> docTypeTxt;

    public WebElement getIdentityLevelTxt() {
        return identityLevelTxt;
    }

    public List<WebElement> getDeleteIdentityDocOption() {
        return deleteIdentityDocOption;
    }

    public List<WebElement> getExpireIdentityDocOption() {
        return expireIdentityDocOption;
    }

    public WebElement getStatusDD() {
        return statusDD;
    }

    public List<WebElement> getDocTypeTxt() {
        return docTypeTxt;
    }
}
