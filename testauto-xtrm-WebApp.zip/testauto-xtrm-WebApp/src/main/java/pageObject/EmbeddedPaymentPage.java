package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmbeddedPaymentPage {
    WebDriver driver;

    public EmbeddedPaymentPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "ctl00_ctl00_TopMenu_MiniTab_btnSubmit")
    private WebElement submitReqBtn;

    public WebElement getSubmitReqBtn() {
        return submitReqBtn;
    }
}
