package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrganizationPage {

    WebDriver driver;

    public OrganizationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "li2")
    private WebElement organizationTab;

    @FindBy(id = "li3")
    private WebElement entitiesTab;

    @FindBy(id = "li1")
    private WebElement usersTab;

    @FindBy(id = "li6")
    private WebElement logoTab;

    public WebElement getOrganizationTab() {
        return organizationTab;
    }

    public WebElement getEntitiesTab() {
        return entitiesTab;
    }

    public WebElement getUsersTab() {
        return usersTab;
    }

    public WebElement getLogoTab() {
        return logoTab;
    }
}
